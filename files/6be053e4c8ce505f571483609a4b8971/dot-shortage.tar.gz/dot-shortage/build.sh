#!/bin/bash

./gradlew shadowJar && ./gradlew buildReadFlag