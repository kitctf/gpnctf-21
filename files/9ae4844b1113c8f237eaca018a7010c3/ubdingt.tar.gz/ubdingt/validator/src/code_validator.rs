use std::process;

use tree_sitter::{Language, Parser};
use tree_sitter_traversal::{traverse, Order};

extern "C" {
    fn tree_sitter_c() -> Language;
}

pub(crate) fn die(message: &str) {
    eprintln!("I am sorry, but I was requested to die a little prematurely :/");
    eprintln!("{message}");
    process::exit(2);
}

pub(crate) fn validate(source_code: &str) {
    let language = unsafe { tree_sitter_c() };
    let mut parser = Parser::new();
    parser.set_language(language).unwrap();

    let tree = parser.parse(source_code, None).unwrap();
    for node in traverse(tree.walk(), Order::Pre) {
        if !node.is_named() {
            continue;
        }
        match node.kind() {
            "comment" => {}

            "assignment_expression"
            | "binary_expression"
            | "call_expression"
            | "cast_expression"
            | "char_literal"
            | "compound_literal_expression"
            | "concatenated_string"
            | "conditional_expression"
            | "false"
            | "field_expression"
            | "number_literal"
            | "parenthesized_expression"
            | "string_literal"
            | "true"
            | "unary_expression"
            | "update_expression" => {}

            "type_identifier" | "field_identifier" | "identifier" => {
                let name = node.utf8_text(source_code.as_bytes()).unwrap();
                if let Some(parent) = node.parent() {
                    if parent.kind() == "function_declarator" && name == "main" {
                        continue;
                    }
                }
                if !name.starts_with("my_id_") {
                    die(&format!(
                        "Identifiers must start with 'my_id_'. \
                      The offending code ranges from {} to {}. \
                      As code: {:?}",
                        node.start_position(),
                        node.end_position(),
                        node.utf8_text(source_code.as_bytes()).unwrap()
                    ))
                }
            }

            "break_statement"
            | "case_statement"
            | "compound_statement"
            | "continue_statement"
            | "do_statement"
            | "expression_statement"
            | "for_statement"
            | "if_statement"
            | "return_statement"
            | "while_statement" => {}

            "parenthesized_declarator" | "function_declarator" => {}
            "primitive_type" | "struct_specifier" | "enum_specifier" => {}
            "argument_list" => {}
            "declaration" | "declaration_list" => {
                if let Some(parent) = node.parent() {
                    if parent.kind() == "translation_unit" {
                        die(&format!(
                            "Global variables are not allowed. \
                          The offending code ranges from {} to {}. \
                          As code: {:?}",
                            node.start_position(),
                            node.end_position(),
                            node.utf8_text(source_code.as_bytes()).unwrap()
                        ))
                    }
                }
            }
            "function_definition" | "type_definition" => {}

            // Fields in structs
            "field_declaration_list" | "field_declaration" => {}

            // e.g. "void"
            "type_descriptor" => {}

            "initializer_list" | "init_declarator" => {}
            "parameter_declaration" | "parameter_list" => {}
            "translation_unit" => {}
            _ => die(&format!(
                "The type of your node, {:?}, was not allowed. \
                  The offending code ranges from {} to {}. \
                  As code: {:?}",
                node.kind(),
                node.start_position(),
                node.end_position(),
                node.utf8_text(source_code.as_bytes()).unwrap()
            )),
        }
    }
}
