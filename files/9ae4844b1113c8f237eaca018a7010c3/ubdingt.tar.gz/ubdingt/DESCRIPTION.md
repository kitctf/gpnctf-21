# Ubedingt
Turmoil on the factory floor: The flag printing machine started rapidly
disassembling itself, even though no capstone binary is in sight...
Technicians, engineers and programmers plead innocent — everything was working
in the debug build, the compiler must have broken the optimized program!

As the insurance inspector for BigCompiler Inc you are certain: This is
impossible. Your compilers' optimizations are sound! Begrudgingly, you try
writing a program that behaves differently when optimizations are turned on.
Your failure will be proof enough!

## Ubedingt Easy
Write a program that behaves differently when optimizations are turned on, but
only if it is compiled with clang. When compiled with gcc it should behave the
same, with and without optimizations.

## Ubedingt Harder
Your program must behave differently in clang, as well as in gcc. Program
errors are handled a bit more loosely now.
