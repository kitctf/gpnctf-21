# heart-and-soul

You are given a binary that "implements" an API proxy server.
Find a way to leak the token from the remote instance.
To do so, you have to find some kind of vulnerability of course:
instead of boring reversing, _make the server binary ready_ for fuzzing and fuzz it using e.g. [afl++](https://github.com/AFLplusplus/AFLplusplus/) (`docker run -ti -v $(pwd):/src aflplusplus/aflplusplus`).

**NOTE**: Do not try to use AFL++ QASAN, it appeared to cause problems when fuzzing. The usage of QASAN is not required to find the bug.
(You can of course try to solve this in any way you want)
