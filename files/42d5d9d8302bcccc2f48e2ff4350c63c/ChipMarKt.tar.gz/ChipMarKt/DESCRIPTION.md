# ChipMarKt

Buy chips right from the fl4gtory at ChipMarKt. Use offer code `kotlin` to get a discount on your next order. Maybe you could even buy so much, you become a premium customer 🥺 👉👈

Go shopping at https://chipmarkt-0.chals.kitctf.de/ or spin up your own webstore with the files provided
