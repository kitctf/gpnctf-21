Note: the deployed version was build using podman and the `Containerfile`.
Since this file seems to cause issues when building with Docker we also provide a `Dockerfile` that should work similar to the deployed version.
Feel free to diff, the change should not affect the challenge.
