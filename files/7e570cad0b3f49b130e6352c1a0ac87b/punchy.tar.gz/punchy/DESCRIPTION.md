# Punchy

An untidy cable run, a sudden breeze and all your source code is blowing in the
wind. And you were *just* done sorting your eco-friendly punchcards: Every
character is inked by hand using the finest ink found in our galaxy
(colloquially known as the "solarized dark" color scheme).

In a stroke of common sense you labeled your cards with incrementing numbers
and then encrypted your vital information with the name of the programming
language you used for each card. Additionally, you also employed some minor
density resolution manipulation (DRM). Each character is represented by a
single dot.

After collecting your cards in a neat ~~jar~~ *tar* you just need to figure out
the language again...

----

Syntax highlighting was done using the rust `syntect` crate. Each line was
truncated to at most 250 chars and each file to 1000 lines. Files with broken
highlighting were already removed from your dataset. Note that you will need
to use the `SyntaxSet::load_defaults_nonewlines()` (NO newlines) version of the
syntax set, if you split lines yourself.
