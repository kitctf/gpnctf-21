import subprocess
import re

print("Please give me the stolen token and you'll get a flag! (github_pat_token_...)")
token = input()

# check whether "token" matches the pattern of a github personal access token:
# `^github_pat_[a-zA-Z0-9]{22}_[a-zA-Z0-9]{59}$`
if not re.match(r"^github_pat_[a-zA-Z0-9]{22}_[a-zA-Z0-9]{59}$", token):
    print("The token appears to not be valid!")
    exit(1)

# Make the curl request to get the content of the "flag.txt" file
response = subprocess.run(["curl", "-H", f"Authorization: Bearer {token}", "-H", "Accept: application/vnd.github.v3.raw", "https://raw.githubusercontent.com/GPNCTF23-ORG/secret/main/flag.txt"], capture_output=True)

# Print the content of the "flag.txt" file
print(response.stdout.decode())
