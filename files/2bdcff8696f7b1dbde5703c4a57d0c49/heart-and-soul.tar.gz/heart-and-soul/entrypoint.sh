#!/bin/bash
./server_v2 &
socat tcp-listen:1337,reuseaddr tcp:localhost:31337